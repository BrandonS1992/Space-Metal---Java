package space.metal;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.image.BufferedImage;
import space.metal.classes.EntityA;
import space.metal.classes.EntityB;
import space.metal.libs.Animation;


public class Player extends GameObject implements EntityA{
    
    private int velX = 0;
    private int velY = 0;
    private Textures textures;
    SpaceMetal spaceGame;
    Controller controller;
    
    Animation anim;
    
    
    //this.x = x means the location is based on the parameters in public player (double x, double y)
    public Player(double x, double y, Textures textures, SpaceMetal spaceGame, Controller controller){
        super(x, y);
        this.textures = textures;
        this.spaceGame = spaceGame;
        this.controller = controller;
        
        anim = new Animation(5, textures.player[0], textures.player[1], textures.player[2]);
    }
    //Same as x + x = velX
    public void frameTick(){
        x+=velX;
        y+=velY;
        //do x <= 0 - 4 on both so x = 0 - 4 if sprite isnt drawn to edge.
        if(x <= 0)
            x = 0;
        if(x >= 906)
            x = 906;
        if(y <= 0)
            y = 0;
        if(y >= 666)
            y = 666;
        
        for(int i = 0; i < spaceGame.eb.size(); i++)
        {
            EntityB tempEnt = spaceGame.eb.get(i);
            
            if(Physics.Collision(this, tempEnt))
            {
                controller.removeEntity(tempEnt);
                SpaceMetal.HEALTH -= 10 * 2;
                spaceGame.setEnemy_killed(spaceGame.getEnemy_killed() + 1);
            }
        }
        anim.runAnimation();
    }
    
    public Rectangle getBounds(){
        return new Rectangle((int)x, (int)y - 54, 64, 64);
    }
    
    public void render(Graphics g){
        anim.drawAnimation(g, x, y - 50, 0);
    }
    
    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }
    public void setX(double x){
        this.x = x;
    }
    public void setY(double y){
        this.y = y;
    }
    public void setVelX(int velX){
        this.velX = velX;
    }
    public void setVelY(int velY){
        this.velY = velY;
    }
    public void frameSpeed() {
        
    }
}
