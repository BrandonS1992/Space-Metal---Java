package space.metal;

import java.awt.Font;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Rectangle;

public class Menu {
    
    public Rectangle playButton = new Rectangle(SpaceMetal.WIDTH / 2 + 180, 320, 150, 50);
    public Rectangle helpButton = new Rectangle(SpaceMetal.WIDTH / 2 + 180, 420, 150, 50);
    public Rectangle exitButton = new Rectangle(SpaceMetal.WIDTH / 2 + 180, 520, 150, 50);
    
    public void render(Graphics g){
        Graphics2D g2d = (Graphics2D) g;
        
        Font fnt0 = new Font("Times New Roman", Font.BOLD + Font.ITALIC, 100);
        g.setFont(fnt0);
        g.setColor(Color.gray);
        g.drawString("Space Metal", SpaceMetal.WIDTH / 2, 200);
        
        Font fnt1 = new Font("Times New Roman", Font.BOLD, 30);
        g.setFont(fnt1);
        g.drawString("Play", playButton.x + 48, playButton.y + 35);
        g2d.draw(playButton);
        g.drawString("Help", helpButton.x + 48, helpButton.y + 35);
        g2d.draw(helpButton);
        g.drawString("Exit", exitButton.x + 48, exitButton.y + 35);
        g2d.draw(exitButton);
        
    }
    
}
