package space.metal;

import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

public class MouseInput implements MouseListener{

    public void mouseClicked(MouseEvent me) {
        
    }

    public void mousePressed(MouseEvent e) 
    {
        int mx = e.getX();
        int my = e.getY();
        /**
        public Rectangle playButton = new Rectangle(SpaceMetal.WIDTH / 2 + 180, 320, 150, 50);
        public Rectangle helpButton = new Rectangle(SpaceMetal.WIDTH / 2 + 180, 420, 150, 50);
        public Rectangle exitButton = new Rectangle(SpaceMetal.WIDTH / 2 + 180, 520, 150, 50);
         */
        //Play Button
        if(mx > SpaceMetal.WIDTH / 2 + 179 && mx <= SpaceMetal.WIDTH / 2 + 330){
            if(my >= 320 && my <= 370)
            {
                //Pressed Play Button
                SpaceMetal.state = SpaceMetal.STATE.GAME;
                
            }
        }
        //Exit Button
        if(mx > SpaceMetal.WIDTH / 2 + 179 && mx <= SpaceMetal.WIDTH / 2 + 330){
            if(my >= 520 && my <= 570)
            {
                //Pressed Exit Button
                System.exit(1);
                
            }
        }
    }

    public void mouseReleased(MouseEvent me) {
        
    }

    public void mouseEntered(MouseEvent me) {
        
    }

    public void mouseExited(MouseEvent me) {
        
    }
    
}
