package space.metal;

import java.util.LinkedList;
import space.metal.classes.EntityA;
import space.metal.classes.EntityB;

public class Physics {
    //if EntityA class runs into EntityB
    public static boolean Collision(EntityA enta, EntityB entb){
            
        if(enta.getBounds().intersects(entb.getBounds())){
            return true;
        }
        return false; 
    }
    
    public static boolean Collision(EntityB entb, EntityA enta){
        
        if(entb.getBounds().intersects(enta.getBounds())){
            return true;
        }
        return false; 
    }
    
}
