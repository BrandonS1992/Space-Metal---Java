package space.metal;

import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;
import space.metal.classes.EntityA;
import space.metal.classes.EntityB;
import space.metal.libs.Animation;

public class EnemyFighter extends GameObject implements EntityB {
    
    private Textures textures;
    Random r = new Random();
    private SpaceMetal spaceGame;
    private Controller c;
    
    
    private int speed = r.nextInt(3) + 2;
    
    Animation anim;
    Animation animD;
    
    public EnemyFighter(double x, double y, Textures textures, Controller c, SpaceMetal spaceGame){
        super (x, y);
        this.textures = textures;
        this.c = c;
        this.spaceGame = spaceGame;
        
        anim = new Animation(5, textures.enemyFighter[0], textures.enemyFighter[1], textures.enemyFighter[2]);
        animD = new Animation(6, textures.enemyFighterD[0], textures.enemyFighterD[1], textures.enemyFighterD[2],
        textures.enemyFighterD[3], textures.enemyFighterD[4], textures.enemyFighterD[5]);
    }
    
    public void frameSpeed(){
        y += speed;
        //resets to top of the screen.
        if(y > SpaceMetal.HEIGHT * SpaceMetal.SCALE){
            speed = r.nextInt(3) + 2;
            x = r.nextInt(640);
            y = -10;
        }
        
        for(int i = 0; i < spaceGame.ea.size(); i++)
        {
            EntityA tempEnt = spaceGame.ea.get(i);
            
            if(Physics.Collision(this, tempEnt))
            {
                c.removeEntity(this);
                c.removeEntity(tempEnt);
                spaceGame.setEnemy_killed(spaceGame.getEnemy_killed() + 1);
            
            }
        }
        anim.runAnimation();

    }
    //cast x and y as integers to prevent error/lossy. drawImage only handles int.
    public void render(Graphics g){
        anim.drawAnimation(g, x, y, 0);

    }
    public Rectangle getBounds(){
        return new Rectangle((int)x, (int)y, 32, 32);
    }
    
    public double getX(){
        return x;
    }
    
    public double getY(){
        return y;
    }
    
    public void setY(double y){
        this.y = y;
    }
}
