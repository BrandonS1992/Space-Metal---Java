package space.metal;

import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class KeyInput extends KeyAdapter{
    
    SpaceMetal spaceGame;
    
    public KeyInput(SpaceMetal snakeGame){
        this.spaceGame = snakeGame;
    }
    
    public void keyPressed(KeyEvent e){
        spaceGame.keyPressed(e);
    }
    public void keyReleased(KeyEvent e){
        spaceGame.keyReleased(e);
    }
}
