package space.metal;

import java.awt.image.BufferedImage;

public class Textures {
    
    public BufferedImage[] player = new BufferedImage[3];
    public BufferedImage[] bullet = new BufferedImage[3];
    public BufferedImage[] enemyFighter = new BufferedImage[3];
    public BufferedImage[] enemyFighterD = new BufferedImage[6];
        
    private SpriteSheet ss;
    
    public Textures(SpaceMetal spaceGame){
        ss = new SpriteSheet(spaceGame.getSpriteSheet());
        
        getTextures();
    }
    
    private void getTextures(){
        player[0] = ss.grabImage(1, 1, 64, 64);
        player[1] = ss.grabImage(1, 3, 64, 64);
        player[2] = ss.grabImage(1, 5, 64, 64);
        
        bullet[0] = ss.grabImage(3, 1, 32, 32);
        bullet[1] = ss.grabImage(3, 2, 32, 32);
        bullet[2] = ss.grabImage(3, 3, 32, 32);
        
        enemyFighter[0] = ss.grabImage(9, 1, 32, 32);
        enemyFighter[1] = ss.grabImage(9, 2, 32, 32);
        enemyFighter[2] = ss.grabImage(9, 3, 32, 32);
        
        enemyFighterD[0] = ss.grabImage(10, 1, 32, 32);
        enemyFighterD[1] = ss.grabImage(10, 2, 32, 32);
        enemyFighterD[2] = ss.grabImage(10, 3, 32, 32);
        enemyFighterD[3] = ss.grabImage(10, 4, 32, 32);
        enemyFighterD[4] = ss.grabImage(10, 5, 32, 32);
        enemyFighterD[5] = ss.grabImage(10, 6, 32, 32);
    }
    
}
